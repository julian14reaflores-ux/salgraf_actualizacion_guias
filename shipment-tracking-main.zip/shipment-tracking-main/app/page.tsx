'use client';

import ShipmentTrackingSystem from '@/components/ShipmentTrackingSystem';

export default function Home() {
  return <ShipmentTrackingSystem />;
}
